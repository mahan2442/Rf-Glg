import { createSupabaseAdminClient } from "@/lib/supabase/admin";

/** Reserve a daily message slot atomically before spending money on a provider call. */
export async function reserveDailyUsage(userId: string, modelId: string): Promise<void> {
  const admin = createSupabaseAdminClient();
  const { data: profile, error: profileError } = await admin.from("profiles").select("plan_id").eq("id", userId).maybeSingle();
  if (profileError) throw new Error("USAGE_CHECK_FAILED");
  const { data: plan, error: planError } = await admin.from("plans").select("daily_message_limit,monthly_token_limit,enabled_model_ids").eq("id", profile?.plan_id ?? "free").maybeSingle();
  if (planError || !plan) throw new Error("USAGE_CHECK_FAILED");
  if (!Array.isArray(plan.enabled_model_ids) || !plan.enabled_model_ids.includes(modelId)) throw new Error("MODEL_NOT_ALLOWED");
  const { data: monthlyTokens, error: monthlyError } = await admin.rpc("current_month_tokens", { p_user_id: userId });
  if (monthlyError) throw new Error("USAGE_CHECK_FAILED");
  if (Number(monthlyTokens ?? 0) >= Number(plan.monthly_token_limit)) throw new Error("MONTHLY_LIMIT_REACHED");
  const { data, error } = await admin.rpc("reserve_daily_message", { p_user_id: userId, p_limit: plan.daily_message_limit });
  if (error) throw new Error("USAGE_CHECK_FAILED");
  if (data !== true) throw new Error("DAILY_LIMIT_REACHED");
}

export async function recordUsage(input: {
  userId: string; provider: string; model: string; inputTokens?: number; outputTokens?: number; status: "success" | "error"; estimatedCostUsd?: number;
}) {
  const admin = createSupabaseAdminClient();
  const { error } = await admin.from("usage_records").insert({
    user_id: input.userId, provider: input.provider, model: input.model,
    input_tokens: input.inputTokens ?? null, output_tokens: input.outputTokens ?? null,
    status: input.status, estimated_cost_usd: input.estimatedCostUsd ?? null, cost_is_estimated: true
  });
  if (error) throw new Error("USAGE_RECORD_FAILED");
}
