export type ZarinpalRequest = { amountRial: number; description: string; callbackUrl: string; email?: string; mobile?: string };
export type ZarinpalRequestResult = { authority: string; paymentUrl: string };
export type ZarinpalVerifyResult = { verified: boolean; refId?: string; code: number };
function config() {
  const merchantId = process.env.ZARINPAL_MERCHANT_ID;
  if (!merchantId) throw new Error("ZARINPAL_NOT_CONFIGURED");
  if (process.env.DEMO_MODE === "true") throw new Error("PAYMENTS_DISABLED_IN_DEMO");
  const sandbox = process.env.ZARINPAL_SANDBOX === "true";
  return { merchantId, api: sandbox ? "https://sandbox.zarinpal.com/pg/v4/payment" : "https://api.zarinpal.com/pg/v4/payment", gateway: sandbox ? "https://sandbox.zarinpal.com/pg/StartPay/" : "https://www.zarinpal.com/pg/StartPay/" };
}
export function assertZarinpalConfigured() { config(); }
export async function requestPayment(input: ZarinpalRequest): Promise<ZarinpalRequestResult> {
  const c = config();
  const response = await fetch(`${c.api}/request.json`, { method: "POST", headers: { "Content-Type": "application/json", "Accept": "application/json" }, cache: "no-store", signal: AbortSignal.timeout(15000), body: JSON.stringify({ merchant_id: c.merchantId, amount: input.amountRial, description: input.description.slice(0, 255), callback_url: input.callbackUrl, metadata: { ...(input.email ? { email: input.email } : {}), ...(input.mobile ? { mobile: input.mobile } : {}) } }) });
  const body = await response.json().catch(() => null);
  const code = body?.data?.code;
  const authority = body?.data?.authority;
  if (!response.ok || code !== 100 || typeof authority !== "string") throw new Error(`ZARINPAL_REQUEST_FAILED:${code ?? response.status}`);
  return { authority, paymentUrl: `${c.gateway}${encodeURIComponent(authority)}` };
}
export async function verifyPayment(authority: string, amountRial: number): Promise<ZarinpalVerifyResult> {
  const c = config();
  const response = await fetch(`${c.api}/verify.json`, { method: "POST", headers: { "Content-Type": "application/json", "Accept": "application/json" }, cache: "no-store", signal: AbortSignal.timeout(15000), body: JSON.stringify({ merchant_id: c.merchantId, amount: amountRial, authority }) });
  const body = await response.json().catch(() => null);
  const code = Number(body?.data?.code ?? body?.errors?.code ?? 0);
  return { verified: response.ok && (code === 100 || code === 101), refId: body?.data?.ref_id != null ? String(body.data.ref_id) : undefined, code };
}
