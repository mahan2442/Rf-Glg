import { requireUser } from "@/lib/auth/require-user";
import { createSupabaseAdminClient } from "@/lib/supabase/admin";
export const dynamic = "force-dynamic";
export async function GET() {
  if (process.env.DEMO_MODE === "true") return Response.json({ error: "پنل مدیریت در حالت نمایشی در دسترس نیست." }, { status: 409 });
  const auth = await requireUser();
  if (!auth.user) return auth.response!;
  const { data: profile } = await auth.supabase.from("profiles").select("role").eq("id", auth.user.id).maybeSingle();
  if (profile?.role !== "admin") return Response.json({ error: "دسترسی مدیر لازم است." }, { status: 403 });
  const admin = createSupabaseAdminClient();
  const [users, conversations, usage, payments, plans] = await Promise.all([
    admin.from("profiles").select("id", { count: "exact", head: true }),
    admin.from("conversations").select("id", { count: "exact", head: true }),
    admin.from("usage_records").select("id,provider,model,status,input_tokens,output_tokens,created_at").order("created_at", { ascending: false }).limit(50),
    admin.from("payments").select("id,status,amount_irr,plan_id,created_at,ref_id").order("created_at", { ascending: false }).limit(50),
    admin.from("plans").select("id,name,price_irr,daily_message_limit,monthly_token_limit,is_active").order("price_irr", { ascending: true })
  ]);
  if (users.error || conversations.error || usage.error || payments.error || plans.error) return Response.json({ error: "دریافت گزارش مدیریتی ناموفق بود." }, { status: 500 });
  const configuredProviders = ["OPENAI_API_KEY", "GEMINI_API_KEY", "ANTHROPIC_API_KEY", "DEEPSEEK_API_KEY", "XAI_API_KEY", "MISTRAL_API_KEY", "OPENROUTER_API_KEY", "PERPLEXITY_API_KEY"].map(key => ({ key, configured: Boolean(process.env[key]) }));
  return Response.json({ stats: { users: users.count ?? 0, conversations: conversations.count ?? 0, recentUsage: usage.data?.length ?? 0, pendingPayments: (payments.data ?? []).filter(p => p.status === "pending").length }, usage: usage.data ?? [], payments: payments.data ?? [], plans: plans.data ?? [], providers: configuredProviders }, { headers: { "Cache-Control": "no-store" } });
}
