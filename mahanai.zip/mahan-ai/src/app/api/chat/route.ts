import { z } from "zod";
import { requireUser } from "@/lib/auth/require-user";
import { getServerModel } from "@/lib/models/catalog";
import { adapterFor } from "@/lib/ai/adapters";
import type { ChatMessage } from "@/lib/ai/types";
import { reserveDailyUsage, recordUsage } from "@/lib/usage/limits";
import { enforceRateLimit } from "@/lib/security/rate-limit";

export const runtime = "nodejs";
const schema = z.object({
  conversationId: z.string().uuid().optional(),
  modelId: z.string().min(1).max(100),
  messages: z.array(z.object({
    role: z.enum(["user", "assistant", "system"]),
    content: z.string().max(16000)
  })).min(1).max(40).refine(items => items.reduce((sum, item) => sum + item.content.length, 0) <= 100000, "Conversation is too long")
});

const demoReply = (prompt: string, modelLabel: string) =>
  `**حالت نمایشی Mahan AI**\n\nپیام شما دریافت شد و رابط کاربری در حالت نمایشی است. برای دریافت پاسخ واقعی، حالت DEMO_MODE را غیرفعال و کلید API معتبر ارائه‌دهنده را در محیط سرور تنظیم کنید.\n\n- مدل انتخاب‌شده: ${modelLabel}\n- طول پیام: ${prompt.length} نویسه\n\nاین متن پاسخ واقعی یک مدل هوش مصنوعی نیست.`;

export async function POST(request: Request) {
  const raw = await request.json().catch(() => null);
  const parsed = schema.safeParse(raw);
  if (!parsed.success) return Response.json({ error: "اطلاعات ارسالی معتبر نیست." }, { status: 400 });

  const { modelId, messages, conversationId } = parsed.data;
  const lastUserMessage = [...messages].reverse().find(m => m.role === "user");
  if (!lastUserMessage || !lastUserMessage.content.trim()) return Response.json({ error: "پیام خالی است." }, { status: 400 });

  const model = getServerModel(modelId);
  if (!model) return Response.json({ error: "این مدل فعال نیست یا کلید اتصال آن تنظیم نشده است." }, { status: 503 });

  // Demo mode is explicitly unauthenticated and never persists data or calls a provider.
  if (process.env.DEMO_MODE !== "false") {
    return Response.json({ text: demoReply(lastUserMessage.content, model.label), model: model.id, demo: true, usage: { estimated: true } });
  }

  const auth = await requireUser();
  if (!auth.user) return auth.response!;
  if (!conversationId) return Response.json({ error: "برای ذخیره امن تاریخچه، یک گفت‌وگوی معتبر بسازید و دوباره تلاش کنید." }, { status: 400 });
  try {
    const rate = await enforceRateLimit(`chat:${auth.user.id}`);
    if (!rate.success) return Response.json({ error: "درخواست‌های زیادی فرستاده‌اید؛ یک دقیقه دیگر تلاش کنید." }, { status: 429, headers: { "Retry-After": "60" } });
  } catch {
    return Response.json({ error: "سامانه محدودیت درخواست در دسترس نیست؛ برای حفظ امنیت درخواست متوقف شد." }, { status: 503 });
  }

  // All conversation ownership checks and writes happen server-side.
  if (conversationId) {
    const { data: conversation, error } = await auth.supabase.from("conversations").select("id,user_id").eq("id", conversationId).maybeSingle();
    if (error || !conversation || conversation.user_id !== auth.user.id) return Response.json({ error: "گفت‌وگو پیدا نشد یا دسترسی ندارید." }, { status: 404 });
  }

  const startedAt = Date.now();
  try {
    await reserveDailyUsage(auth.user.id, model.id);
    const adapter = adapterFor(model);
    const normalizedMessages = messages.map(m => ({ role: m.role, content: m.content })) as ChatMessage[];
    const result = await adapter.generate(model, normalizedMessages, AbortSignal.timeout(60000));
    await recordUsage({
      userId: auth.user.id, provider: model.provider, model: model.id,
      inputTokens: result.usage.inputTokens, outputTokens: result.usage.outputTokens, status: "success"
    });

    if (conversationId) {
      const { error } = await auth.supabase.from("messages").insert([
        { conversation_id: conversationId, user_id: auth.user.id, role: "user", content: lastUserMessage.content, model_id: model.id },
        { conversation_id: conversationId, user_id: auth.user.id, role: "assistant", content: result.text, model_id: model.id, input_tokens: result.usage.inputTokens ?? null, output_tokens: result.usage.outputTokens ?? null }
      ]);
      if (error) console.error("message_persist_failed", { userId: auth.user.id, code: error.code });
      else await auth.supabase.from("conversations").update({ updated_at: new Date().toISOString(), model_id: model.id }).eq("id", conversationId).eq("user_id", auth.user.id);
    }
    console.info("ai_request_completed", { userId: auth.user.id, provider: model.provider, model: model.id, durationMs: Date.now() - startedAt });
    return Response.json({ text: result.text, model: model.id, demo: false, usage: result.usage });
  } catch (error) {
    const message = error instanceof Error ? error.message : "UNKNOWN";
    console.error("ai_request_failed", { userId: auth.user.id, model: model.id, errorCode: message.split(":")[0] });
    if (message === "DAILY_LIMIT_REACHED") return Response.json({ error: "سهمیه روزانه شما به پایان رسیده است. پلن خود را ارتقا دهید." }, { status: 429 });
    if (message === "MONTHLY_LIMIT_REACHED") return Response.json({ error: "سقف مصرف توکن ماهانه شما به پایان رسیده است. پلن خود را ارتقا دهید." }, { status: 429 });
    if (message === "MODEL_NOT_ALLOWED") return Response.json({ error: "پلن فعلی شما اجازه استفاده از این مدل را نمی‌دهد." }, { status: 403 });
    if (message === "USAGE_CHECK_FAILED") return Response.json({ error: "بررسی سهمیه ممکن نشد؛ لطفاً بعداً تلاش کنید." }, { status: 503 });
    const friendly = message === "PROVIDER_NOT_CONFIGURED" ? "اتصال این ارائه‌دهنده تنظیم نشده است." :
      message.startsWith("PROVIDER_ERROR:429") ? "محدودیت درخواست ارائه‌دهنده؛ کمی بعد دوباره تلاش کنید." :
      message.startsWith("PROVIDER_ERROR:") ? "ارائه‌دهنده نتوانست درخواست را پردازش کند. تنظیمات مدل را بررسی کنید." :
      message.includes("timeout") ? "زمان پاسخ‌گویی مدل تمام شد. دوباره تلاش کنید." : "در ارتباط با مدل خطایی رخ داد.";
    return Response.json({ error: friendly }, { status: 502 });
  }
}
