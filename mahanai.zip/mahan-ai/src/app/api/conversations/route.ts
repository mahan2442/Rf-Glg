import { z } from "zod";
import { requireUser } from "@/lib/auth/require-user";

export const dynamic = "force-dynamic";
export async function GET() {
  if (process.env.DEMO_MODE === "true") return Response.json({ conversations: [], demo: true });
  const auth = await requireUser();
  if (!auth.user) return auth.response!;
  const { data, error } = await auth.supabase.from("conversations").select("id,title,model_id,updated_at,messages(id,role,content,model_id,created_at)").order("updated_at", { ascending: false }).limit(100);
  if (error) return Response.json({ error: "بارگذاری تاریخچه ناموفق بود." }, { status: 500 });
  return Response.json({ conversations: data ?? [] }, { headers: { "Cache-Control": "no-store" } });
}
const createSchema = z.object({ id: z.string().uuid().optional(), title: z.string().trim().min(1).max(120), modelId: z.string().max(100).optional() });
export async function POST(request: Request) {
  if (process.env.DEMO_MODE === "true") return Response.json({ error: "ذخیره‌سازی در حالت نمایشی غیرفعال است." }, { status: 409 });
  const auth = await requireUser();
  if (!auth.user) return auth.response!;
  const parsed = createSchema.safeParse(await request.json().catch(() => null));
  if (!parsed.success) return Response.json({ error: "اطلاعات گفت‌وگو معتبر نیست." }, { status: 400 });
  const { data, error } = await auth.supabase.from("conversations").insert({ ...(parsed.data.id ? { id: parsed.data.id } : {}), user_id: auth.user.id, title: parsed.data.title, model_id: parsed.data.modelId ?? null }).select("id,title,model_id,updated_at").single();
  if (error) return Response.json({ error: "ساخت گفت‌وگو ناموفق بود." }, { status: 500 });
  return Response.json({ conversation: data }, { status: 201 });
}
